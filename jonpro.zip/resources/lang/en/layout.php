<?php

return [
    'welcome' => 'Welcome',
    'home' => 'Home',
    'projects' => 'Projects',
    'users' => 'Users',
    'companies' => 'Companies',
    'settings' => 'Settings'
];
