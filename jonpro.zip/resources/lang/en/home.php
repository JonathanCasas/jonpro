<?php

return [
    'pending_tasks' => 'All Pending Tasks',
    'today_pending_tasks' => 'Pending Tasks',
    'table' => [
        'id' => '#',
        'name' => 'Name',
        'type' => 'Type',
        'priority' => 'Priority',
        'project' => 'Project',
        'action' => '...',
        'state' => 'State',
        'estimated_time' => 'Estimated time',
        'start_date' => 'Start Date',
        'end_date' => 'End Date'
    ]
];

