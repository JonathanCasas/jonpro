<?php $__env->startSection('page_title','Projects'); ?>

<?php $__env->startSection('content'); ?>
<div class="col-lg-2 col-md-2 col-sm-2 col-xs-2">
    <a href="<?php echo e(route('projects.create')); ?>" class="btn btn-success">
        <i class="fa fa-plus"></i>
        Add Project
    </a>
</div>
<div class="row clearfix">
    <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
        <div class="x_panel">
            <div class="x_title">
                <div class="row">
                    <div class="col-lg-10 col-md-10 col-sm-10 col-xs-10">
                        <h2>
                            All Projects
                        </h2>
                    </div>

                </div>
            </div>
            <div class="x_content">
                <div class="body table-responsive">
                    <form action="<?php echo e(route('projects.index')); ?>" method="GET" id="search">
                        <table class="table table-hover">
                            <thead>
                                <tr>
                                    <th>#</th>
                                    <th>Name</th>
                                    <th>State</th>
                                    <th>Priority</th>
                                    <th>Start Date</th>
                                    <th>Created By</th>
                                    <th>Company</th>
                                    <th>Action</th>
                                </tr>
                                <tr>
                                    <th>
                                        <input type="hidden" name="filter" value="true">
                                        <input type="text" name="id" id="id" min="0" class="form-control" style="width: 4em" value="<?php echo e($request->get('id')); ?>">
                                    </th>
                                    <th><input type="text" name="name" id="name" class="form-control" style="width: 8em" value="<?php echo e($request->get('name')); ?>"></th>
                                    <th>
                                        <select class="form-control jonpro-select" name="state" id="state">
                                            <option value="">--Select--</option>
                                            <?php $__currentLoopData = $states; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $state): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($state); ?>" <?php echo e($state==$request->get('state')?'selected':''); ?>><?php echo e($state); ?></option>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </select>
                                    </th>
                                    <th>
                                        <select class="form-control jonpro-select" name="priority" id="priority">
                                            <option value="">--Select--</option>
                                            <?php $__currentLoopData = $priorities; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $priority): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($priority); ?>" <?php echo e($priority==$request->get('priority')?'selected':''); ?>><?php echo e($priority); ?></option>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </select>
                                    </th>
                                    <th><input type="text" name="start_date" id="start_date" class="form-control date" style="width: 8em" value="<?php echo e($request->get('start_date')); ?>"></th>
                                    <th>
                                        <select class="form-control users" name="created_by" id="created_by">
                                            <?php if(!is_null($createdBy)): ?>
                                            <option value="<?php echo e($createdBy->id); ?>" selected=""><?php echo e($createdBy->name); ?></option>
                                            <?php endif; ?>
                                        </select>
                                    </th>
                                    <th>
                                        <select class="form-control companies" id="company" name="company">
                                            <?php if(!is_null($company)): ?>
                                            <option value="<?php echo e($company->id); ?>" selected=""><?php echo e($company->name); ?></option>
                                            <?php endif; ?>
                                        </select>
                                    </th>
                                    <th>
                                        <button class="btn btn-dark btn-sm" type="submit">
                                            <i class="fa fa-filter"></i>
                                        </button>
                                        <a class="btn btn-danger btn-sm" href="<?php echo e(route('projects.index')); ?>">
                                            <i class="fa fa-dashcube"></i>
                                        </a>
                                    </th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php if($projects->isNotEmpty()): ?>
                                <?php $__currentLoopData = $projects; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $project): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <th scope="row"><?php echo e($project->id); ?></th>
                                    <td><?php echo e($project->name); ?></td>
                                    <td><?php echo e($project->state); ?></td>
                                    <td><?php echo e($project->priority); ?></td>
                                    <td><?php echo e(!is_null($project->start_date)?$project->start_date->format('Y-m-d'):''); ?></td>
                                    <td><?php echo e($project->creator->name); ?></td>
                                    <td><?php echo e($project->company->name); ?></td>
                                    <td>
                                        <a href="<?php echo e(route('projects.edit',['project'=>$project])); ?>" class="btn btn-warning btn-sm">
                                            <i class="fa fa-pencil"></i>
                                        </a>
                                        <a href="<?php echo e(route('projects.show',['project'=>$project])); ?>" class="btn btn-info btn-sm">
                                            <i class="fa fa-eye"></i>
                                        </a>
                                    </td>
                                </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <?php endif; ?>
                            </tbody>
                        </table>
                    </form>
                    <?php if($projects->isEmpty()): ?>
                    <div>
                        No results found
                    </div>
                    <?php endif; ?>
                    <div>
                        <?php echo e($projects->appends($request->all())->render()); ?>

                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('js'); ?>
<script>
    $(document).ready(function () {
        $('.date').inputmask("yyyy-mm-dd");
        $jp('.companies').companies("<?php echo e(route('companies.ajax.select2')); ?>");
        $jp('.users').users("<?php echo e(route('users.ajax.select2')); ?>", "Search users");
        $('.jonpro-select').select2({
            width: '100%'
        });
        $('.reset').click(function () {
            $('.form-control').val('');
            $('#state,#priority,#created_by,#company').val([]).trigger('change');
            //location.reload(false);
            $('#search').submit();
            //window.location = window.location;
            //$('#id,#name,#state,#priority,#start_date,#created_by,#company').val('');
        });
    });
</script>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.jonpro', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>