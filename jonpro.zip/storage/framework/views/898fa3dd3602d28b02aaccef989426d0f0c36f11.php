<?php $__env->startSection('css_main'); ?>
<link rel="stylesheet" type="text/css" href="<?php echo e(asset('gentella/vendors/select2/dist/css/select2.min.css')); ?>">
<?php echo $__env->yieldContent('css'); ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('main'); ?>
<div class="container body">
    <div class="main_container">
        <div class="col-md-3 left_col">
            <div class="left_col scroll-view">
                <div class="navbar nav_title" style="border: 0;">
                    <a href="index.html" class="site_title"><i class="fa fa-paw"></i> <span><?php echo e(Jonpro::getSiteTitle()); ?></span></a>
                </div>

                <div class="clearfix"></div>

                <!-- menu profile quick info -->
                <div class="profile clearfix">
                    <div class="profile_pic">
                        <img src="<?php echo e(asset('gentella/production/images/img.jpg')); ?>" alt="..." class="img-circle profile_img">
                    </div>
                    <div class="profile_info">
                        <span><?php echo e(trans('layout.welcome')); ?>,</span>
                        <h2><?php echo e(auth()->user()->nombre); ?></h2>
                    </div>
                </div>
                <!-- /menu profile quick info -->

                <br />

                <!-- sidebar menu -->
                <div id="sidebar-menu" class="main_menu_side hidden-print main_menu">
                    <div class="menu_section">
                        <h3>General</h3>
                        <ul class="nav side-menu">
                            <li class="<?php echo e(isActiveRoute('home')); ?><?php echo e(isActiveRoute('home2')); ?>"><a href="<?php echo e(route('home')); ?>"><i class="fa fa-home"></i> <?php echo e(__('layout.home')); ?></a></li>
                            <li class="<?php echo e(isActiveRoute('projects.*')); ?>"><a href="<?php echo e(route('projects.index')); ?>"><i class="fa fa-folder"></i> <?php echo e(__('layout.projects')); ?></a></li>
                            <li class="<?php echo e(isActiveRoute('users.*')); ?>"><a href="<?php echo e(route('users.index')); ?>"><i class="fa fa-users"></i> <?php echo e(__('layout.users')); ?></a></li>
                            <li class="<?php echo e(isActiveRoute('companies.*')); ?>"><a href="<?php echo e(route('companies.index')); ?>"><i class="fa fa-institution"></i> <?php echo e(__('layout.companies')); ?></a></li>
                            <li class="<?php echo e(isActiveRoute('settings.*')); ?>"><a href="<?php echo e(route('settings.create')); ?>"><i class="fa fa-gears"></i> <?php echo e(__('layout.settings')); ?></a></li>
                        </ul>
                    </div>
                </div>
                <!-- /sidebar menu -->

                <!-- /menu footer buttons -->
                <div class="sidebar-footer hidden-small">
                    <a data-toggle="tooltip" data-placement="top" title="Settings">
                        <span class="glyphicon glyphicon-cog" aria-hidden="true"></span>
                    </a>
                    <a data-toggle="tooltip" data-placement="top" title="FullScreen">
                        <span class="glyphicon glyphicon-fullscreen" aria-hidden="true"></span>
                    </a>
                    <a data-toggle="tooltip" data-placement="top" title="Lock">
                        <span class="glyphicon glyphicon-eye-close" aria-hidden="true"></span>
                    </a>
                    <a data-toggle="tooltip" data-placement="top" title="Logout" href="login.html">
                        <span class="glyphicon glyphicon-off" aria-hidden="true"></span>
                    </a>
                </div>
                <!-- /menu footer buttons -->
            </div>
        </div>

        <!-- top navigation -->
        <div class="top_nav">
            <div class="nav_menu">
                <nav>
                    <div class="nav toggle">
                        <a id="menu_toggle"><i class="fa fa-bars"></i></a>
                    </div>

                    <ul class="nav navbar-nav navbar-right">
                        <li class="">
                            <a href="javascript:;" class="user-profile dropdown-toggle" data-toggle="dropdown" aria-expanded="false">
                                <img src="images/img.jpg" alt="">John Doe
                                <span class=" fa fa-angle-down"></span>
                            </a>
                            <ul class="dropdown-menu dropdown-usermenu pull-right">
                                <li><a href="javascript:;"> Profile</a></li>
                                <li>
                                    <a href="javascript:;">
                                        <span class="badge bg-red pull-right">50%</span>
                                        <span>Settings</span>
                                    </a>
                                </li>
                                <li><a href="javascript:;">Help</a></li>
                                <li><a href="login.html"><i class="fa fa-sign-out pull-right"></i> Log Out</a></li>
                            </ul>
                        </li>

                        <li role="presentation" class="dropdown">
                            <a href="javascript:;" class="dropdown-toggle info-number" data-toggle="dropdown" aria-expanded="false">
                                <i class="fa fa-envelope-o"></i>
                                <span class="badge bg-green">6</span>
                            </a>
                            <ul id="menu1" class="dropdown-menu list-unstyled msg_list" role="menu">
                                <li>
                                    <a>
                                        <span class="image"><img src="images/img.jpg" alt="Profile Image" /></span>
                                        <span>
                                            <span>John Smith</span>
                                            <span class="time">3 mins ago</span>
                                        </span>
                                        <span class="message">
                                            Film festivals used to be do-or-die moments for movie makers. They were where...
                                        </span>
                                    </a>
                                </li>
                                <li>
                                    <a>
                                        <span class="image"><img src="images/img.jpg" alt="Profile Image" /></span>
                                        <span>
                                            <span>John Smith</span>
                                            <span class="time">3 mins ago</span>
                                        </span>
                                        <span class="message">
                                            Film festivals used to be do-or-die moments for movie makers. They were where...
                                        </span>
                                    </a>
                                </li>
                                <li>
                                    <a>
                                        <span class="image"><img src="images/img.jpg" alt="Profile Image" /></span>
                                        <span>
                                            <span>John Smith</span>
                                            <span class="time">3 mins ago</span>
                                        </span>
                                        <span class="message">
                                            Film festivals used to be do-or-die moments for movie makers. They were where...
                                        </span>
                                    </a>
                                </li>
                                <li>
                                    <a>
                                        <span class="image"><img src="images/img.jpg" alt="Profile Image" /></span>
                                        <span>
                                            <span>John Smith</span>
                                            <span class="time">3 mins ago</span>
                                        </span>
                                        <span class="message">
                                            Film festivals used to be do-or-die moments for movie makers. They were where...
                                        </span>
                                    </a>
                                </li>
                                <li>
                                    <div class="text-center">
                                        <a>
                                            <strong>See All Alerts</strong>
                                            <i class="fa fa-angle-right"></i>
                                        </a>
                                    </div>
                                </li>
                            </ul>
                        </li>
                    </ul>
                </nav>
            </div>
        </div>
        <!-- /top navigation -->

        <!-- page content -->
        <div class="right_col" role="main">

            <div class="row">
                <div class="page-title">
                    <div class="title_left">
                        <h3><?php echo $__env->yieldContent('page_title'); ?></h3>
                    </div>
                    <div class="title_right">
                        <div class="col-md-5 col-sm-5 col-xs-12 form-group pull-right top_search">
                            <div class="input-group">
                                <input type="text" class="form-control" placeholder="Search for...">
                                <span class="input-group-btn">
                                    <button class="btn btn-default" type="button">Go!</button>
                                </span>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <?php echo $__env->make('flash::message', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
            <?php if($errors->any()): ?>
            <div class="alert alert-danger">
                <ul>
                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li><?php echo e($error); ?></li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
            </div>
            <?php endif; ?>


            <?php if (! empty(trim($__env->yieldContent('button_add')))): ?>
            <div class="row">
                <div class="col-md-12 col-sm-12 col-xs-12 col-lg-12">
                    <a href="<?php echo $__env->yieldContent('link'); ?>" class="btn btn-success"><?php echo $__env->yieldContent('button_add'); ?> <i class="fa fa-plus"></i></a>
                </div>
            </div>
            <?php endif; ?>
            <div class="clearfix"></div>
            <?php if (! empty(trim($__env->yieldContent('before_panel')))): ?>
            <div class="row">
                <?php echo $__env->yieldContent('before_panel'); ?>
            </div>
            <div class="clearfix"></div>
            <?php endif; ?>

            <?php echo $__env->yieldContent('content'); ?>

        </div>
        <!--/page content-->
    </div>
</div>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('js_main'); ?>

<script src="<?php echo e(asset('gentella/vendors/select2/dist/js/select2.min.js')); ?>"></script>
<script src="<?php echo e(asset('js/jonpro.js')); ?>"></script>
<!-- jquery.inputmask -->
<script src="<?php echo e(asset('gentella/vendors/jquery.inputmask/dist/min/jquery.inputmask.bundle.min.js')); ?>"></script>
<?php echo $__env->yieldContent('js'); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.layout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>