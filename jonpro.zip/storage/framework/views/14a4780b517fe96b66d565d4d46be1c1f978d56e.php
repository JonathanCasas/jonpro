<?php $__env->startSection('page_title','Home'); ?>

<?php $__env->startSection('content'); ?>
<div class="row clearfix">
    <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
        <div class="x_panel">
            <div class="x_title">
                <h2>
                    <?php echo e(__('home.pending_tasks')); ?>

                </h2>
                <div class="clearfix"></div>
            </div>
            <div class="x_content">
                <div class="table-responsive">
                    <form action="<?php echo e(route('home.alltasks')); ?>" method="GET">
                        <table class="table table-hover">
                            <thead>
                                <tr>
                                    <th><?php echo e(__('home.table.id')); ?></th>
                                    <th><?php echo e(__('home.table.name')); ?></th>
                                    <th><?php echo e(__('home.table.type')); ?></th>
                                    <th><?php echo e(__('home.table.priority')); ?></th>
                                    <th><?php echo e(__('home.table.project')); ?></th>
                                    <th><?php echo e(__('home.table.state')); ?></th>
                                    <th><?php echo e(__('home.table.estimated_time')); ?></th>
                                    <th><?php echo e(__('home.table.start_date')); ?></th>
                                    <th><?php echo e(__('home.table.end_date')); ?></th>
                                    <th><?php echo e(__('home.table.action')); ?></th>
                                </tr>
                                <tr>
                                    <th><input type="text" name="id" value="<?php echo e($request->get('id')); ?>" class="form-control"></th>
                                    <th><input type="text" name="name" value="<?php echo e($request->get('name')); ?>" class="form-control"></th>
                                    <th>
                                        <select name="type" class="form-control jonpro-select">
                                            <option value="">-- Select --</option>
                                            <?php $__currentLoopData = $types; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $type): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($type); ?>" <?php echo e($type==$request->get('type')?'selected':''); ?>><?php echo e($type); ?></option>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </select>
                                    </th>
                                    <th>
                                        <select name="priority" class="form-control jonpro-select">
                                            <option value="">-- Select --</option>
                                            <?php $__currentLoopData = $priorities; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $priority): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($priority); ?>" <?php echo e($priority==$request->get('priority')?'selected':''); ?>><?php echo e($priority); ?></option>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </select>
                                    </th>
                                    <th>
                                        <?php
                                        $project=null;
                                        if($request->has('project')&&!is_null($request->get('project'))){
                                        $project=\App\Models\Project::find($request->get('project'));
                                        }  
                                        ?>
                                        <select class="form-control projects" name="project">
                                            <?php if(!is_null($project)): ?>
                                            <option value="<?php echo e($project->id); ?>" selected=""><?php echo e($project->name); ?></option>
                                            <?php endif; ?>
                                        </select>
                                    </th>
                                    <th>
                                        <select class="form-control" name="state">
                                            <option value="">--Select--</option>
                                            <?php $__currentLoopData = $states; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $state): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($state); ?>" <?php echo e($state==$request->get('state')?'selected':''); ?>><?php echo e($state); ?></option>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </select>
                                    </th>
                                    <th><input type="text" name="estimated_time" value="<?php echo e($request->get('estimated_time')); ?>" class="form-control"></th>
                                    <th><input type="text" name="start_date" value="<?php echo e($request->get('start_date')); ?>" placeholder="yyyy-mm-dd" class="form-control date"></th>
                                    <th><input type="text" name="end_date" value="<?php echo e($request->get('end_date')); ?>" placeholder="yyyy-mm-dd" class="form-control date"></th>
                                    <th>
                                        <button type="submit" name="filter" value="true" class="btn btn-dark btn-sm">
                                            <i class="fa fa-filter"></i>
                                        </button>
                                    </th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php if($tasks->isNotEmpty()): ?>
                                <?php $__currentLoopData = $tasks; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $task): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <th class="row"><?php echo e($task->id); ?></th>
                                    <td><?php echo e($task->name); ?></td>
                                    <td><?php echo e($task->type); ?></td>
                                    <td><?php echo e($task->priority); ?></td>
                                    <td><?php echo e($task->project->name); ?></td>
                                    <td><?php echo e($task->state); ?></td>
                                    <td><?php echo e($task->estimated_time); ?></td>
                                    <td><?php echo e(!is_null($task->start_date)?$task->start_date->format('Y-m-d'):''); ?></td>
                                    <td><?php echo e(!is_null($task->end_date)?$task->end_date->format('Y-m-d'):''); ?></td>
                                    <td>
                                        <button class="btn btn-info btn-sm task" task="<?php echo e($task->id); ?>">
                                            <i class="fa fa-eye"></i>
                                        </button>
                                    </td>
                                </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <?php endif; ?>
                            </tbody>
                        </table>
                    </form>
                    <?php if($tasks->isEmpty()): ?>
                    <div>
                        No results found
                    </div>
                    <?php endif; ?>
                    <div>
                        <?php echo e($tasks->appends($request->only(['id', 'name', 'type', 'priority', 'project', 'filter','state','stimated_time','start_date','end_date']))->render()); ?>

                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('js'); ?>
<script>
    $(document).ready(function () {
        $jp('.projects').select2("<?php echo e(route('projects.search.select2')); ?>", "Projects");
        $('.date').inputmask("yyyy-mm-dd");
    });

</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.jonpro', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>